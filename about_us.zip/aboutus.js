// function work() {
//     var email1 = document.getElementById("exampleInputEmail1").value;
//     var password1 = document.getElementById("exampleInputPassword1").value;
//     //email-id = wanigaurav24@gmail.com
//     //Password = gvk
//     if (email1 == "wanigaurav24@gmail.com" && password1 == "gvk") {
//         document.getElementById("head6").innerHTML = "Website is developed by Gaurav, Khushal and Vilas.";
//         alert("you are logged in");
//     } else {
//         alert("Incorrect Email-id or password");
//     }
// }